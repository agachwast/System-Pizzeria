﻿using ProjketC;

namespace PizzeriaGUI
{
    partial class DodajPracownika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            comboBox1 = new ComboBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16F, FontStyle.Bold);
            label1.Location = new Point(276, 18);
            label1.Name = "label1";
            label1.Size = new Size(250, 32);
            label1.TabIndex = 0;
            label1.Text = "Dodaj pracownika";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(276, 75);
            label2.Name = "label2";
            label2.Size = new Size(38, 20);
            label2.TabIndex = 1;
            label2.Text = "Imie";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(242, 115);
            label3.Name = "label3";
            label3.Size = new Size(72, 20);
            label3.TabIndex = 2;
            label3.Text = "Nazwisko";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(105, 157);
            label4.Name = "label4";
            label4.Size = new Size(209, 20);
            label4.TabIndex = 3;
            label4.Text = "Data urodzenia (dd/MM/yyyy)";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(276, 207);
            label5.Name = "label5";
            label5.Size = new Size(42, 20);
            label5.TabIndex = 4;
            label5.Text = "Pesel";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(51, 254);
            label6.Name = "label6";
            label6.Size = new Size(263, 20);
            label6.TabIndex = 5;
            label6.Text = "Data rozpoczęcia pracy (dd/MM/yyyy)";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(258, 303);
            label7.Name = "label7";
            label7.Size = new Size(56, 20);
            label7.TabIndex = 6;
            label7.Text = "Stawka";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(230, 349);
            label8.Name = "label8";
            label8.Size = new Size(84, 20);
            label8.TabIndex = 7;
            label8.Text = "Stanowisko";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(345, 75);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(299, 27);
            textBox1.TabIndex = 8;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(345, 112);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(299, 27);
            textBox2.TabIndex = 9;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(345, 154);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(299, 27);
            textBox3.TabIndex = 10;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(345, 204);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(299, 27);
            textBox4.TabIndex = 11;
    
            // 
            // textBox5
            // 
            textBox5.Location = new Point(345, 247);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(299, 27);
            textBox5.TabIndex = 12;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(345, 300);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(299, 27);
            textBox6.TabIndex = 13;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Items.AddRange(new object[] { "kelner", "kucharz_junior", "kucharz_senior", "menadżer", "sprzątaczka" });
            comboBox1.Location = new Point(345, 349);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(299, 28);
            comboBox1.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = Color.LightGreen;
            button1.Font = new Font("Arial", 10F, FontStyle.Bold);
            button1.Location = new Point(677, 314);
            button1.Name = "button1";
            button1.Size = new Size(105, 70);
            button1.TabIndex = 15;
            button1.Text = "Dodaj";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // DodajPracownika
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(comboBox1);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "DodajPracownika";
            Text = "DodajPracownika";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private ComboBox comboBox1;
        private Button button1;
    }
}