﻿namespace PizzeriaGUI
{
    partial class Menu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label1 = new Label();
            button4 = new Button();
            label2 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.Orange;
            button1.Font = new Font("Arial", 10F, FontStyle.Bold);
            button1.Location = new Point(161, 175);
            button1.Name = "button1";
            button1.Size = new Size(146, 65);
            button1.TabIndex = 0;
            button1.Text = "Lista Klientów";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button2_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.LightYellow;
            button2.Font = new Font("Arial", 10F, FontStyle.Bold);
            button2.Location = new Point(164, 282);
            button2.Name = "button2";
            button2.Size = new Size(143, 58);
            button2.TabIndex = 1;
            button2.Text = "Lista pracowników";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // button3
            // 
            button3.BackColor = Color.LightBlue;
            button3.Font = new Font("Arial", 10F, FontStyle.Bold);
            button3.Location = new Point(476, 175);
            button3.Name = "button3";
            button3.Size = new Size(143, 65);
            button3.TabIndex = 2;
            button3.Text = "Zarejestruj zamówienie";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16F, FontStyle.Bold);
            label1.Location = new Point(295, 64);
            label1.Name = "label1";
            label1.Size = new Size(204, 32);
            label1.TabIndex = 3;
            label1.Text = "Strona główna";
            // 
            // button4
            // 
            button4.BackColor = Color.LightPink;
            button4.Font = new Font("Arial", 10F, FontStyle.Bold);
            button4.Location = new Point(481, 282);
            button4.Name = "button4";
            button4.Size = new Size(138, 58);
            button4.TabIndex = 4;
            button4.Text = "Historia zamówień";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 16F, FontStyle.Bold);
            label2.Location = new Point(325, 21);
            label2.Name = "label2";
            label2.Size = new Size(139, 32);
            label2.TabIndex = 5;
            label2.Text = "PiZZERIA";
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(button4);
            Controls.Add(label1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Menu";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Label label1;
        private Button button4;
        private Label label2;
    }
}
