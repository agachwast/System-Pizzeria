﻿namespace PizzeriaGUI
{
    partial class UsunPracownika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16F, FontStyle.Bold);
            label1.Location = new Point(273, 25);
            label1.Name = "label1";
            label1.Size = new Size(242, 32);
            label1.TabIndex = 0;
            label1.Text = "Usuń pracownika";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(229, 116);
            label2.Name = "label2";
            label2.Size = new Size(104, 20);
            label2.TabIndex = 1;
            label2.Text = "ID pracownika";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(378, 113);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(188, 27);
            textBox1.TabIndex = 2;

            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 102, 102);
            button1.Font = new Font("Arial", 13F, FontStyle.Bold);
            button1.Location = new Point(291, 190);
            button1.Name = "button1";
            button1.Size = new Size(217, 91);
            button1.TabIndex = 3;
            button1.Text = "USUŃ";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // UsunPracownika
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "UsunPracownika";
            Text = "UsunPracownika";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private Button button1;
    }
}