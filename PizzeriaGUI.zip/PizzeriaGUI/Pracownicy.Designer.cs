﻿namespace PizzeriaGUI
{
    partial class Pracownicy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            listBoxPracownicy = new ListBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            label1.Location = new Point(220, 30);
            label1.Name = "label1";
            label1.Size = new Size(328, 31);
            label1.TabIndex = 0;
            label1.Text = "LISTA PRACOWNIKÓW";
            // 
            // listBoxPracownicy
            // 
            listBoxPracownicy.FormattingEnabled = true;
            listBoxPracownicy.Location = new Point(25, 127);
            listBoxPracownicy.Name = "listBoxPracownicy";
            listBoxPracownicy.Size = new Size(569, 284);
            listBoxPracownicy.TabIndex = 1;
  
            // 
            // button1
            // 
            button1.BackColor = Color.LightGreen;
            button1.Font = new Font("Arial", 10F, FontStyle.Bold);
            button1.Location = new Point(613, 130);
            button1.Name = "button1";
            button1.Size = new Size(164, 57);
            button1.TabIndex = 2;
            button1.Text = "Dodaj";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(255, 102, 102);
            button2.Font = new Font("Arial", 10F, FontStyle.Bold);
            button2.Location = new Point(613, 204);
            button2.Name = "button2";
            button2.Size = new Size(164, 60);
            button2.TabIndex = 3;
            button2.Text = "Usuń";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.LightYellow;
            button3.Font = new Font("Arial", 10F, FontStyle.Bold);
            button3.Location = new Point(613, 283);
            button3.Name = "button3";
            button3.Size = new Size(164, 66);
            button3.TabIndex = 4;
            button3.Text = "Pokaż informację o pracowniku";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // Pracownicy
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(listBoxPracownicy);
            Controls.Add(label1);
            Name = "Pracownicy";
            Text = "Pracownicy";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private ListBox listBoxPracownicy;
        private Button button1;
        private Button button2;
        private Button button3;
    }
}