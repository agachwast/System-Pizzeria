﻿namespace PizzeriaGUI
{
    partial class ListaKlientow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ListBoxZwykliKlienci = new ListBox();
            label1 = new Label();
            ListBoxLoyalKlienci = new ListBox();
            label3 = new Label();
            label4 = new Label();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // ListBoxZwykliKlienci
            // 
            ListBoxZwykliKlienci.FormattingEnabled = true;
            ListBoxZwykliKlienci.Location = new Point(45, 305);
            ListBoxZwykliKlienci.Name = "ListBoxZwykliKlienci";
            ListBoxZwykliKlienci.Size = new Size(731, 124);
            ListBoxZwykliKlienci.TabIndex = 0;
            // 
            // label1
            // 
            label1.Font = new Font("Arial", 16F, FontStyle.Bold);
            label1.Location = new Point(237, 25);
            label1.Name = "label1";
            label1.Size = new Size(246, 36);
            label1.TabIndex = 0;
            label1.Text = "LISTA KLIENTÓW";
            // 
            // ListBoxLoyalKlienci
            // 
            ListBoxLoyalKlienci.FormattingEnabled = true;
            ListBoxLoyalKlienci.Location = new Point(42, 137);
            ListBoxLoyalKlienci.Name = "ListBoxLoyalKlienci";
            ListBoxLoyalKlienci.Size = new Size(732, 124);
            ListBoxLoyalKlienci.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 10F, FontStyle.Bold);
            label3.Location = new Point(45, 109);
            label3.Name = "label3";
            label3.Size = new Size(108, 19);
            label3.TabIndex = 2;
            label3.Text = "Klienci Loyal";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 10F, FontStyle.Bold);
            label4.Location = new Point(45, 282);
            label4.Name = "label4";
            label4.Size = new Size(146, 19);
            label4.TabIndex = 3;
            label4.Text = "Klienci Non-Loyal";
            // 
            // button1
            // 
            button1.Font = new Font("Arial", 10F, FontStyle.Bold);
            button1.BackColor = Color.LightGreen;
            button1.Location = new Point(624, 86);
            button1.Name = "button1";
            button1.Size = new Size(146, 42);
            button1.TabIndex = 4;
            button1.Text = "Dodaj";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Arial", 10F, FontStyle.Bold);
            button2.BackColor = Color.LightGreen;
            button2.Location = new Point(625, 264);
            button2.Name = "button2";
            button2.Size = new Size(151, 36);
            button2.TabIndex = 5;
            button2.Text = "Dodaj";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // ListaKlientow
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(ListBoxLoyalKlienci);
            Controls.Add(label1);
            Controls.Add(ListBoxZwykliKlienci);
            Name = "ListaKlientow";
            Text = "ListaKlientow";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox ListBoxZwykliKlienci;
        private Label label1;
        private ListBox ListBoxLoyalKlienci;
        private Label label3;
        private Label label4;
        private Button button1;
        private Button button2;
    }
}