﻿namespace PizzeriaGUI
{
    partial class PokazInfoPracownik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            label1.Location = new Point(149, 26);
            label1.Name = "label1";
            label1.Size = new Size(499, 31);
            label1.TabIndex = 0;
            label1.Text = "Wyświetlenie informacji o pracowniku";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(178, 104);
            label2.Name = "label2";
            label2.Size = new Size(171, 20);
            label2.TabIndex = 1;
            label2.Text = "Id/Nazwisko pracownika";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(378, 97);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(256, 27);
            textBox1.TabIndex = 2;

            // 
            // button1
            // 
            button1.BackColor = Color.LightYellow;
            button1.Font = new Font("Arial", 10F, FontStyle.Bold);
            button1.Location = new Point(294, 170);
            button1.Name = "button1";
            button1.Size = new Size(172, 81);
            button1.TabIndex = 3;
            button1.Text = "Wyświetl";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // PokazInfoPracownik
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "PokazInfoPracownik";
            Text = "PokazInfoPracownik";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private Button button1;
    }
}