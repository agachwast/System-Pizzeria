﻿using ProjketC;
using System.Windows.Forms.VisualStyles;

namespace PizzeriaGUI
{
    partial class RejestracjaZamowienia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label5 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            checkBox1 = new CheckBox();
            comboBox1 = new ComboBox();
            button1 = new Button();
            label4 = new Label();
            comboBox2 = new ComboBox();
            label6 = new Label();
            comboBox3 = new ComboBox();
            label8 = new Label();
            textBox3 = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            label1.Location = new Point(233, 32);
            label1.Name = "label1";
            label1.Size = new Size(326, 31);
            label1.TabIndex = 0;
            label1.Text = "Rejestracja Zamówienia";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(21, 127);
            label2.Name = "label2";
            label2.Size = new Size(161, 20);
            label2.TabIndex = 1;
            label2.Text = "Numer telefonu klienta";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(79, 179);
            label3.Name = "label3";
            label3.Size = new Size(103, 20);
            label3.TabIndex = 2;
            label3.Text = "ID Pracownika";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(49, 234);
            label5.Name = "label5";
            label5.Size = new Size(133, 20);
            label5.TabIndex = 4;
            label5.Text = "Status zamówienia";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(188, 124);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(200, 27);
            textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(188, 179);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(200, 27);
            textBox2.TabIndex = 6;
            // 
            // checkBox1
            // 
            checkBox1.Location = new Point(238, 274);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(150, 24);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Czy zapłacone?";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Items.AddRange(new object[] { "Oczekujace", "WTrakcieRealizacji", "Zakonczone", "Anulowane" });
            comboBox1.Location = new Point(188, 231);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(200, 28);
            comboBox1.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = Color.LightBlue;
            button1.Font = new Font("Arial", 10F, FontStyle.Bold);
            button1.Location = new Point(452, 326);
            button1.Name = "button1";
            button1.Size = new Size(243, 53);
            button1.TabIndex = 7;
            button1.Text = "Dodaj zamówienie";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(458, 124);
            label4.Name = "label4";
            label4.Size = new Size(101, 20);
            label4.TabIndex = 8;
            label4.Text = "Rozmiar Pizzy";
            // 
            // comboBox2
            // 
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.Items.AddRange(new object[] { "mala", "srednia", "duza" });
            comboBox2.Location = new Point(582, 119);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(160, 28);
            comboBox2.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(493, 182);
            label6.Name = "label6";
            label6.Size = new Size(66, 20);
            label6.TabIndex = 10;
            label6.Text = "Dodatek";
            // 
            // comboBox3
            // 
            comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox3.Items.AddRange(new object[] { "pieczarka", "papryka", "salami", "kurczak", "burrata", "oliwki" });
            comboBox3.Location = new Point(582, 176);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(160, 28);
            comboBox3.TabIndex = 11;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(520, 239);
            label8.Name = "label8";
            label8.Size = new Size(39, 20);
            label8.TabIndex = 14;
            label8.Text = "Ilość";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(582, 236);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(160, 27);
            textBox3.TabIndex = 15;
    
            // 
            // RejestracjaZamowienia
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox3);
            Controls.Add(label8);
            Controls.Add(comboBox3);
            Controls.Add(label6);
            Controls.Add(comboBox2);
            Controls.Add(label4);
            Controls.Add(button1);
            Controls.Add(comboBox1);
            Controls.Add(checkBox1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "RejestracjaZamowienia";
            Text = "Re";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label5;
        private TextBox textBox1;
        private TextBox textBox2;
        private CheckBox checkBox1;
        private ComboBox comboBox1;
        private Button button1;
        private Label label4;
        private ComboBox comboBox2;
        private Label label6;
        private ComboBox comboBox3;
        private Label label8;
        private TextBox textBox3;
    }
}